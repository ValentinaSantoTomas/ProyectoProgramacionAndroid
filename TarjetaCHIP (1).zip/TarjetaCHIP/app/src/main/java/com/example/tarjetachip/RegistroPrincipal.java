package com.example.tarjetachip;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegistroPrincipal extends AppCompatActivity {

    private TextView monto;
    private EditText montoagregado;

    public Integer montototal = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_principal);

        monto = (TextView) findViewById(R.id.textView2);
        montoagregado = (EditText) findViewById(R.id.editTextNumberDecimal2);

        String dato = getIntent().getStringExtra("monto");

        monto.setText("" + dato);
    }

    public void agregarmonto(View view) {
        Integer montorecibo = Integer.parseInt(montoagregado.getText().toString());

        Integer montoalmacenado = Integer.parseInt(monto.getText().toString());

        if (montorecibo >= 1000){
            montototal = montoalmacenado + montorecibo;

            monto.setText("" + montototal);
        }else{
            Toast.makeText(this,"Debes ingresar un monto igual o superior a 1000 pesos", Toast.LENGTH_SHORT).show();
        }
    }

    public void boletotaxi(View view) {
        Integer montorecibo = Integer.parseInt(monto.getText().toString());

        if (montorecibo >= 600){
            monto.setText("" + (montorecibo-600));


        }else{
            Toast.makeText(this,"Saldo insuficiente", Toast.LENGTH_SHORT).show();
        }

    }

    public void boletometro(View view) {
        Integer montorecibo = Integer.parseInt(monto.getText().toString());

        if (montorecibo >= 750){
            monto.setText("" + (montorecibo-750));


        }else{
            Toast.makeText(this,"Saldo insuficiente", Toast.LENGTH_SHORT).show();
        }
    }

    public void historialTaxi(View view) {
        Intent siguiente = new Intent(this, Adapter.class);

        siguiente.putExtra("monto", 600);

        startActivity(siguiente);
    }

    public void historialMetro(View view) {
        Intent siguiente = new Intent(this, Adapter.class);

        siguiente.putExtra("monto", 750);

        startActivity(siguiente);
    }
}