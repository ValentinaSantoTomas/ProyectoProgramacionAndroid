package com.example.tarjetachip;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adaptador extends RecyclerView.Adapter<Adaptador.ViewHolder> {
    private ArrayList<Pasaje> pasajes;

    public Adaptador(ArrayList<Pasaje> pasajes){
        this.pasajes = pasajes;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.tarjeta, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.foto.setText(pasajes.get(position).getId());
        holder.nombre.setText(pasajes.get(position).getCosto());
        holder.numero.setText(pasajes.get(position).getCodigoseguridad());
    }

    @Override
    public int getItemCount() {
        return pasajes.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        private TextView foto;
        private TextView nombre;
        private TextView numero;

        public ViewHolder(View itemView){
            super(itemView);

            foto = itemView.findViewById(R.id.textView7);
            nombre = itemView.findViewById(R.id.textView9);
            numero = itemView.findViewById(R.id.textView10);
        }
    }
}
