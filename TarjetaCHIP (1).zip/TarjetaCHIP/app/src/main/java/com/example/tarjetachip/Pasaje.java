package com.example.tarjetachip;

import java.text.DateFormat;
import java.util.Date;

public class Pasaje {
    private int id;
    private int costo;
    private int codigoseguridad;

    public Pasaje() {
        id = 0;
        costo = 0;
        codigoseguridad = 0;
    }

    public Pasaje(int id, int costo, int codigoseguridad) {
        this.id = id;
        this.costo = costo;
        this.codigoseguridad = codigoseguridad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCosto() {
        return costo;
    }

    public void setCosto(int costo) {
        this.costo = costo;
    }

    public int getCodigoseguridad() {
        return codigoseguridad;
    }

    public void setCodigoseguridad(int codigoseguridad) {
        this.codigoseguridad = codigoseguridad;
    }

    @Override
    public String toString() {
        return "Pasaje{" +
                "id=" + id +
                ", costo=" + costo +
                ", codigoseguridad=" + codigoseguridad +
                '}';
    }
}
