package com.example.tarjetachip;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText monto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        monto = (EditText) findViewById(R.id.editTextNumberDecimal);
    }

    public void siguiente(View view) {
        Integer montorecibo = Integer.parseInt(monto.getText().toString());

        if (montorecibo >= 5000){
            Intent siguiente = new Intent(this, RegistroPrincipal.class);

            siguiente.putExtra("monto", monto.getText().toString());

            startActivity(siguiente);
        }else{
            Toast.makeText(this,"Debes ingresar un monto igual o superior a 5000 pesos", Toast.LENGTH_SHORT).show();
        }

    }
}