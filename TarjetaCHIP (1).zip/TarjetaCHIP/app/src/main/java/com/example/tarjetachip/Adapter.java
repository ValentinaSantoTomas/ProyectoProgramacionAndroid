package com.example.tarjetachip;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Adapter extends AppCompatActivity {

    RecyclerView recyclerPasajes;
    Adaptador adaptador;
    ArrayList<Pasaje> pasajes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adapter);
        Integer dato = Integer.getInteger(getIntent().getStringExtra("monto"));

        inicializar();
    }

    private void inicializar() {
        recyclerPasajes = findViewById(R.id.listaPasajes);
        recyclerPasajes.setLayoutManager(new LinearLayoutManager(this));
        
        llenarContactos();

        adaptador = new Adaptador(pasajes);
        recyclerPasajes.setAdapter(adaptador);
    }

    private void llenarContactos() {
        pasajes = new ArrayList<Pasaje>();


        pasajes.add(new Pasaje(0, 600, 60000));
        pasajes.add(new Pasaje(0, 600, 60000));
        pasajes.add(new Pasaje(0, 600, 60000));
        pasajes.add(new Pasaje(0, 600, 60000));
    }
}